# Full_ArrayList

Esqueleto, implementaciones y testeo de Array List para parcial 2 de laboratorio 1.


Para usar todas las carpetas, solamente reemplacen mis archivos arrayList.c y arrayList.h por el de ustedes
y ya pueden utilizar las implementaciones de los modelos en base a sus arrayList y modificarlos si no son compatibles.

AL_Implementacion_x: Son los modelos de examen que vi hasta ahora.

AL_New: Es el esteleto que yo, Franas el mas capo, uso para empezar siempre un examen, solo con las librerias de ArrayList. Esta medio rancio, pero no falla.

AL_Utest: Es el testeo que tienen ustedes pero ya esta incluido aca de onda y tenia un error arreglado que ya no me acuerdo que es porque paso hace mil años mas que queres.



Espero que les sirva cualquier cosa hagan fork y commit y manden mensaje al grupo, gatitos. <3 
